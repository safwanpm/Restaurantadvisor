import React, { useEffect, useState } from 'react'
import Navbar from '../../components/User/navbar/Navbar'
import Footer from '../../components/Home/footer/Footer'
import Bg_mra from '../../components/Hotel/bg-mra/Bg_mra'
import Review_mra from '../../components/Hotel/bg-mra/Review_mra'
import axios from 'axios'

function Mra() {
  

  return (
    <>

      <section>
        <Navbar />
        <div>
        </div>
        <div >
          <Bg_mra />
        </div>
      </section>
      <Review_mra />
      <Footer /></>

  )
}


export default Mra