import React from 'react'
import Admin_bg from '../../components/Admin/Admin_bg'
import Navbar from '../../components/User/navbar/Navbar'
import Footer from '../../components/Home/footer/Footer'

function Adminpage() {
  return (
    <>
    <Navbar/><br/><br/>
    <Admin_bg/>
    <Footer/>
    </>
  )
}

export default Adminpage