import React from 'react'
import Bg_kannur from '../../../components/User/bg-kannur/Bg_kannur'
import Navbar from '../../../components/User/navbar/Navbar'
import Footer from '../../../components/Home/footer/Footer'


function Kannur() {





  return (
    <>
   <Navbar/>
   <Bg_kannur/>
   <Footer/>
    </>
  )
}

export default Kannur