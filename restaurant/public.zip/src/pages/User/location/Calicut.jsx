import React from 'react'
import Navbar from '../../components/User/navbar/Navbar'
import Bg_kannur from '../../components/User/bg-kannur/Bg_kannur'
import Footer from '../../components/Home/footer/Footer'

function Calicut() {
    return (
        <div>
            <Navbar />
            <Bg_kannur />
            <Footer />
        </div>
    )
}

export default Calicut