import React from 'react'
import Navbar from '../../components/User/navbar/Navbar'
import Login from '../../components/Home/login/Login'
import Footer from '../../components/Home/footer/Footer'
import MainHome_navbar from '../../components/Home/MainHome_navbar'

function Loginpg() {


  return (
    <>
      <MainHome_navbar />
      <Login ></Login>

    </>
  )
}

export default Loginpg