const express = require('express')
const RegisterModel = require('../model/RegisterModel')
const RestaurantRegisterModel = require('../model/RestaurantRegisterModel')
const AddHotelModel = require('../model/AddHotelModel')
const LoginModel = require('../model/LoginModel')
const RegisterRouter = express.Router()
var bcrypt = require('bcryptjs');
const multer = require('multer')
const path = require('path');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const destinationPath = path.join(__dirname, './public/uploads');
        cb(null, destinationPath)
    },
    filename: function (req, file, cb) {

        cb(null, req.body.logo)
    }
})

const upload = multer({ storage: storage })

RegisterRouter.post('/upload', upload.single('file'), (req, res) => {
    res.status(200).json({
        message: "logo added"
    })
})

RegisterRouter.post('/save-user', async (req, res) => {
    try {
        const { username, password, email, phone } = req.body;
        console.log(req.body);
        const hashedPass = await bcrypt.hash(password, 12)
        const loginData = {
            username: username,
            password: hashedPass,
            role: "1",
            status: "0"
        }

        const logins = await LoginModel(loginData).save()
        console.log('log', loginData);
        const details = {
            loginId: logins._id,
            email: email,
            phone: phone,
        }

        const user = await RegisterModel(details).save()

        if (user) {
            return res.status(200).json({
                success: true,
                error: false,
                message: "added"
            })
        }
        else {

        }

    }
    catch (error) {
        return res.status(400).json({
            success: true,
            error: false,
            message: "can't add"
        })
    }






})




RegisterRouter.post('/save-restaurant', async (req, res) => {
    try {



        const { username, password, email, district } = req.body;
        console.log(req.body);
        const hashedPass = await bcrypt.hash(password, 12)
        const loginData = {
            username: username,
            password: hashedPass,
            role: "2",
            status: "0"
        }

        const logins = await LoginModel(loginData).save()
        console.log('log', loginData);
        const details = {
            loginId: logins._id,
            email: email,
            district: district
        }

        const user = await RestaurantRegisterModel(details).save()

        if (user) {
            return res.status(200).json({
                success: true,
                error: false,
                message: "added"
            })
        }
        else {

        }

    }
    catch (error) {
        return res.status(400).json({
            success: true,
            error: false,
            message: "can't add"
        })
    }



})
RegisterRouter.post('/save-login', async (req, res) => {
    try {
        const { username, password } = req.body
        const user = await LoginModel.findOne({ username })
        if (!user) {
            return res.status(400).json({
                success: false,
                error: true,
                message: "user not found"
            })
        }

        const encrypt = await bcrypt.compare(password, user.password)
        console.log('user', user);
        if (encrypt == true) {
            if (user.role == 1) {
                const Users = await RegisterModel.findOne({ loginId: user._id })
                return res.status(200).json({
                    success: true,
                    error: false,
                    role: user.role,
                    login_id: user._id,
                    user_id: Users._id,
                    message: " User Login successfully"
                })
            }
            if (user.role == 2) {
                const hotel = await RestaurantRegisterModel.findOne({ loginId: user._id })
                return res.status(200).json({
                    success: true,
                    error: false,
                    role: user.role,
                    login_id: user._id,
                    hotel_id: hotel._id,
                    message: " Hotel Login successfully"
                })
            }

        }

        if (encrypt == false) {
            return res.status(400).json({
                success: true,
                error: false,
                message: "Check Password..!"
            })
        }


    }
    catch (error) {
        return res.status(400).json({
            success: true,
            error: false,
            message: "can't login"
        })
    }
})


RegisterRouter.post('/save-hotel', async (req, res) => {
    try {
        const data = {
            name: req.body.name,
            district: (req.body.district).toLowerCase(),
            email: req.body.email,
            place: req.body.place,
            pin: req.body.pin,
            time: req.body.time,
            phone: req.body.phone,
            special: req.body.special,
            meals: req.body.meals,
            features: req.body.features,
            logo: req.body.logo,
            hotelId: req.body.hotelId
            // image1:req.file.filename,
            // image2:req.file.filename,

        }
        console.log('data', data);
        const user = await AddHotelModel(data).save()

        if (user) {
            return res.status(200).json({
                success: true,
                error: false,
                message: "added"
            })
        }
        else {


        }

    }
    catch (error) {
        return res.status(400).json({
            success: true,
            error: false,
            message: "can't add"
        })
    }
})



RegisterRouter.get('/view-hotel/:id', async (req, res) => {
    try {
        const item = req.params.id;
        const HotelDetails = await AddHotelModel.findOne({ hotelId: item })
        // console.log(contactDetails);
        if (HotelDetails) {
            return res.status(200).json({
                success: true,
                error: false,
                data: HotelDetails
            })
        }
    }
    catch (error) {
    }
})



// RegisterRouter.post('/delete/:id', async(req, res) => {
//     try {
//         const id = req.params.id
//         const contactDetails =await RegisterModel.deleteOne({_id:id})
//         console.log(contactDetails);
//         if(contactDetails){
//             return res.status(200).json({
//                 success: true,
//                 error: false,
//                 message: 'deleted'
//             })
//         }
//     } catch (error) {
//     }

// })

module.exports = RegisterRouter